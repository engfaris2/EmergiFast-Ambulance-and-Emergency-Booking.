package com.example.last_minute_driver

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
