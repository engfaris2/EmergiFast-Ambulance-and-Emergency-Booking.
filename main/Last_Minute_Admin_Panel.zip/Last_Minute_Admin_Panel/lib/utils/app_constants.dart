// ignore_for_file: constant_identifier_names

class AppConstants{
  static const String APP_NAME = "Quick_Sellers";
  static const int APP_VERSION = 1;

  static const String BASE_URL = "https://api.airtable.com/v0/appNafBekDdjSEiQt";//"https://techville.getgrist.com";

  static const String POPULAR_PRODUCT_URI = "/Products?view=AvailableProducts";//"/api/docs/kWHSc5h2i1GAqxA6wP95QX/tables/GroceryUsers/records?";

  static const String RECOMMENDED_PRODUCT_URI = "/Products?view=AvailableProducts";//"/api/docs/kWHSc5h2i1GAqxA6wP95QX/tables/GroceryUsers/records?";//"/api/docs/kWHSc5h2i1GAqxA6wP95QX/tables/GroceryUsers/records?";

  static const String TOKEN = "keydn34O3fhfNivSO";//"2420be228c356569707bcb2e7f79ac37898e57a6";//"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYyNDVhN2JhNGE2ZWQxOTM3MDI5NzgwZiIsImlhdCI6MTY3MDQyNDQzOCwiZXhwIjoxNjczMDE2NDM4fQ.kMItQ51mX7ET5YbxCosQzMoC-SgTRkAU_a54qp9W6yk";

}