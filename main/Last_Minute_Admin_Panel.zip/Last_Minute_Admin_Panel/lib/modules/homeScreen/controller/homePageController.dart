import 'package:flutter/material.dart';
import 'package:get/get.dart';

class HomePageController extends GetxController {
  TextEditingController distance = TextEditingController();
  TextEditingController symptoms = TextEditingController();
  TextEditingController problem = TextEditingController();
  TextEditingController condition = TextEditingController();
}
