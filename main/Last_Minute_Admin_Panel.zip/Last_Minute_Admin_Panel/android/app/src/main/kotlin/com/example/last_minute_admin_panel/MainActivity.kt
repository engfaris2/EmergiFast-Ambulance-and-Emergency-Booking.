package com.example.last_minute_admin_panel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
