# LAST MINUTE 

## Last Minute Prototype (Patient):

<p align="center">
  <img width="640" height="360" src="https://user-images.githubusercontent.com/95934322/209422248-12b237f3-0e45-47bf-b950-16585970454f.png">
</p>

<p align="center">
  <img width="640" height="360" src="https://user-images.githubusercontent.com/95934322/209422363-ee49b5e8-dd20-4db1-a87d-92a725362b77.png">
</p>


## Last Minute Prototype (Driver/ EMT's)

<p align="center">
  <img width="640" height="360" src="https://user-images.githubusercontent.com/95934322/209422610-1441577c-24ba-40c4-80c6-47fa1fdd98ae.png">
</p>

